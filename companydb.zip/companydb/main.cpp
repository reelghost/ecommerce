#include "Company.h"
#include "Employee.h"
#include "Customer.h"
#include "Purchase.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits>
#include <sstream>

// Function to load data from the company-specific data file
void loadData(const std::string& companyName, std::vector<Employee>& employees, std::vector<Customer>& customers) {
    std::ifstream inputFile(companyName + ".dat");

    if (!inputFile.is_open()) {
        // The file doesn't exist, so there's no data to load yet.
        return;
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        std::istringstream iss(line);
        std::string type;
        iss >> type;

        if (type == "Employee") {
            std::string name, phone, email;
            double salary;
            iss >> name >> phone >> email >> salary;
            employees.push_back(Employee(name, phone, email, salary));
        } else if (type == "Customer") {
            std::string name, phone, email;
            iss >> name >> phone >> email;
            Customer newCustomer(name, phone, email);

            // Read purchase data for the customer
            while (std::getline(inputFile, line)) {
                if (line.empty()) {
                    break; // End of customer data
                }
                std::istringstream purchaseIss(line);
                std::string item;
                int qty;
                double cost;
                purchaseIss >> item >> qty >> cost;
                Purchase purchase(item, qty, cost);
                newCustomer.add_purchase(purchase);
            }

            customers.push_back(newCustomer);
        }
    }

    inputFile.close();
}

// Function to save both employee and customer data to the company-specific data file
void saveData(const std::string& companyName, const std::vector<Employee>& employees, const std::vector<Customer>& customers) {
    std::ofstream outputFile(companyName + ".dat");

    if (!outputFile.is_open()) {
        std::cerr << "Error: Could not open file " << companyName << ".dat" << std::endl;
        return;
    }

    // Save employee data
    for (const Employee& emp : employees) {
        outputFile << "Employee " << emp.name() << " " << emp.phone() << " " << emp.email() << " " << emp.salary() << std::endl;
    }

    // Save customer data
    for (const Customer& cust : customers) {
        outputFile << "Customer " << cust.name() << " " << cust.phone() << " " << cust.email() << std::endl;

        // Save purchase data for the customer
        for (Customer::const_iterator it = cust.purchase_begin(); it != cust.purchase_end(); ++it) {
            outputFile << "Purchase " << it->item() << " " << it->qty() << " " << it->cost() << std::endl;
        }
    }

    outputFile.close();
}

int main() {
    std::string companyName;

    // Step 1: Prompt for the company name
    std::cout << "Enter the company name: ";
    std::getline(std::cin, companyName);

    // Step 2: Create a Company instance and load data
    Company myCompany(companyName);
    myCompany.loadCompanyData();

    // Declare vectors to store employee and customer data
    std::vector<Employee> employees;
    std::vector<Customer> customers;

    // Step 3: Load existing data
    loadData(companyName, employees, customers);

    // Step 4: Display the menu and handle user choices
    int choice;
    do {
        std::cout << "\nMenu:\n";
        std::cout << "1. View/Add Employees\n";
        std::cout << "2. View/Add Sales and Customers\n";
        std::cout << "3. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
            {
                // View/Add Employees
                std::cout << "1. View Employees\n";
                std::cout << "2. Add Employee\n";
                std::cout << "3. Go Back\n";
                std::cout << "Enter your choice: ";
                int empChoice;
                std::cin >> empChoice;

                switch (empChoice) {
                    case 1:
                        // View Employees
                        std::cout << "Employee List:\n";
                        for (const Employee& emp : employees) {
                            std::cout << "Name: " << emp.name() << " | Phone: " << emp.phone()
                                      << " | Email: " << emp.email() << " | Salary: " << emp.salary() << std::endl;
                        }
                        break;
                    case 2:
                    {
                        // Add Employee
                        std::string name, phone, email;
                        double salary;

                        std::cout << "Enter employee name: ";
                        std::cin.ignore();
                        std::getline(std::cin, name);

                        std::cout << "Enter employee phone: ";
                        std::cin >> phone;

                        std::cout << "Enter employee email: ";
                        std::cin >> email;

                        std::cout << "Enter employee salary: ";
                        std::cin >> salary;

                        // Create a new Employee object and add it to the vector
                        Employee newEmployee(name, phone, email, salary);
                        employees.push_back(newEmployee);

                        std::cout << "Employee added successfully.\n";
                        break;
                    }
                    case 3:
                        // Go back to the main menu
                        break;
                    default:
                        std::cout << "Invalid choice. Please try again.\n";
                        break;
                }
                break;
            }
            case 2:
            {
                // View/Add Sales and Customers
                std::cout << "1. View Sales\n";
                std::cout << "2. Add Customer\n";
                std::cout << "3. Go Back\n";
                std::cout << "Enter your choice: ";
                int salesChoice;
                std::cin >> salesChoice;

                switch (salesChoice) {
                    case 1:
                    {
                        // View Sales
                        std::cout << "Sales History:\n";
                        for (const Customer& cust : customers) {
                            std::cout << "Customer: " << cust.name() << std::endl;
                            for (Customer::const_iterator it = cust.purchase_begin(); it != cust.purchase_end(); ++it) {
                                std::cout << "Item: " << it->item() << " | Quantity: " << it->qty() << " | Cost: " << it->cost() << " | Total: " << it->total() << std::endl;
                            }
                            std::cout << "---------------------------------------------\n";
                        }
                        break;
                    }
                    case 2:
                    {
                        // Add Customer
                        std::string custName, custPhone, custEmail;

                        std::cout << "Enter customer name: ";
                        std::cin.ignore();
                        std::getline(std::cin, custName);

                        std::cout << "Enter customer phone: ";
                        std::cin >> custPhone;

                        std::cout << "Enter customer email: ";
                        std::cin >> custEmail;

                        // Create a new Customer object
                        Customer newCustomer(custName, custPhone, custEmail);

                        // Add purchases for the customer
                        while (true) {
                            std::string item;
                            int qty;
                            double cost;

                            std::cout << "Enter purchased item (or type 'done' to finish adding purchases): ";
                            std::cin.ignore();
                            std::getline(std::cin, item);

                            if (item == "done") {
                                break; // Exit the loop when 'done' is entered
                            }

                            std::cout << "Enter quantity: ";
                            std::cin >> qty;

                            std::cout << "Enter cost per item: ";
                            std::cin >> cost;

                            // Create a new Purchase object
                            Purchase purchase(item, qty, cost);

                            // Add the purchase to the customer's history
                            newCustomer.add_purchase(purchase);
                        }

                        // Add the customer to the vector
                        customers.push_back(newCustomer);

                        std::cout << "Customer added successfully.\n";
                        break;
                    }
                    case 3:
                        // Go back to the main menu
                        break;
                    default:
                        std::cout << "Invalid choice. Please try again.\n";
                        break;
                }
                break;
            }
            case 3:
                // Exit the program and save all data
                // Save data
                saveData(companyName, employees, customers);

                // Save company data (if needed)
                myCompany.saveCompanyData();

                std::cout << "Exiting the program. Data saved successfully.\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
                break;
        }

        // Clear the input buffer
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    } while (choice != 3);

    // Step 5: Save data before exiting
    saveData(companyName, employees, customers);
    myCompany.saveCompanyData();

    return 0;
}
